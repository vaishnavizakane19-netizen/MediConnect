# MediConnect — College Project

A white + sky-blue healthcare appointment booking demo with patient, doctor and admin screens. Doctor cards use illustrative photos and are marked as sample/demo profiles. Do not present sample profiles as real or verified clinicians.

## What's included
- `client/`: React + Vite presentation website. The supplied UI demo saves demo accounts, appointments and statuses in this browser's local storage.
- `server/`: Express + MongoDB API for registration/login, approved doctor listings, appointment requests, doctor decisions, admin approvals and simulated ₹20 payment status.
- Optional SMTP email notifications from the API if configured.

**Important:** The client UI currently runs in browser demo mode and does not automatically call the API. The API is included as a separate backend starter; connecting every UI action to it would be a further integration step. Do not treat this package as a production healthcare/payment system. The demo payment does not charge real money.

## 1. Start the website UI (quick presentation mode)
1. Install Node.js LTS.
2. Open a terminal in the `client` folder.
3. In PowerShell/VS Code terminal run:
   ```powershell
   npm.cmd install
   npm.cmd run dev
   ```
4. Open the local URL Vite prints, usually `http://localhost:5173`.

Demo admin credentials in the browser UI: `admin@mediconnect.demo` / `Admin@123`.

## 2. Start the backend API (optional; needs MongoDB)
1. Install and start MongoDB Community locally, or create a MongoDB Atlas database.
2. In `server`, copy `.env.example` to `.env` and set `MONGODB_URI` and a long `JWT_SECRET`.
3. Install dependencies and start API:
   ```powershell
   npm.cmd install
   npm.cmd run dev
   ```
4. In a second terminal, from `server`, run `npm.cmd run create-admin` to create the API admin user from `.env`.
5. API health check: `http://localhost:5000/api/health`.

The API has JWT auth and role checks. Email notifications are optional and require SMTP settings in `.env`. Keep credentials private and change demo passwords before any real deployment.


## Admin dashboard update
The Admin dashboard now includes appointment request listings and demo payment records, including demo-fee totals. These are browser-local presentation records only; they are not real payment settlements or shared online database records. The patient can mark the ₹20 demo fee as completed after a confirmed appointment, and the Admin view reflects that demo state in the same browser.
