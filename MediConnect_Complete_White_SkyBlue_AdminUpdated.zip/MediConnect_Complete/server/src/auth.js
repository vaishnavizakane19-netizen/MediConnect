import jwt from 'jsonwebtoken';
export function signToken(user){return jwt.sign({id:user._id,role:user.role},process.env.JWT_SECRET,{expiresIn:'2d'});}
export async function requireAuth(req,res,next){try{const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!token)return res.status(401).json({message:'Please sign in.'});req.auth=jwt.verify(token,process.env.JWT_SECRET);next();}catch{return res.status(401).json({message:'Session expired. Please sign in again.'});}}
export const requireRole=(...roles)=>(req,res,next)=>roles.includes(req.auth?.role)?next():res.status(403).json({message:'You do not have permission for this action.'});
